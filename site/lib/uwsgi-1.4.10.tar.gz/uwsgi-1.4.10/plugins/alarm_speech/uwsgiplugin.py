NAME='alarm_speech'

CFLAGS = []
LDFLAGS = []
LIBS = ['-framework appkit']
GCC_LIST = ['alarm_speech.m']
