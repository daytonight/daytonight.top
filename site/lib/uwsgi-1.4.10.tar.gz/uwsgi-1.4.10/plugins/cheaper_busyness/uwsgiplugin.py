NAME='cheaper_busyness'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['cheaper_busyness']
