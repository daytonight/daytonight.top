
NAME='fastrouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

REQUIRES = ['corerouter']

GCC_LIST = ['fastrouter']
